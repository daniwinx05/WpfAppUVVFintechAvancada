﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Model;
using WpfAppUVVFintechAvancada.Repositories;

namespace WpfAppUVVFintechAvancada.Controller
{
    internal class LoginController
    {
        private readonly AdministradorRepository adminRepo = new AdministradorRepository();
        private readonly ClienteRepository clienteRepo = new ClienteRepository();

        public object Login(string tipo, string nome, string senha)
        {
            tipo = tipo.Trim().ToUpper();

            if (tipo == "ADM")
            {
                return adminRepo.Login(nome, senha);
            }
            else if (tipo == "CLM")
            {
                return clienteRepo.LoginPorNome(nome, senha);
            }

            return null;
        }
    }
}

