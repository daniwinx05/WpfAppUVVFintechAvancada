﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Model;
using WpfAppUVVFintechAvancada.Repositories;

namespace WpfAppUVVFintechAvancada.Controller
{
    internal class ContaController
    {
        private readonly ContaRepository repo = new ContaRepository();

        // OBTER CONTA POR ID
        public Conta ObterConta(int contaId)
        {
            return repo.ObterPorId(contaId);
        }

        // LISTAR TODAS AS CONTAS DE UM CLIENTE
        public List<Conta> ObterContasDoCliente(int clienteId)
        {
            return repo.BuscarPorCliente(clienteId);
        }

        // OBTER SALDO
        public decimal ObterSaldo(int contaId)
        {
            return repo.ObterSaldo(contaId);
        }

        // DEPÓSITO (CORRENTE E POUPANÇA SÃO IGUAIS)
        public void Depositar(int contaId, decimal valor)
        {
            if (valor <= 0)
                throw new Exception("O valor do depósito deve ser maior que zero.");

            var conta = repo.ObterPorId(contaId);
            if (conta == null)
                throw new Exception("Conta não encontrada.");

            repo.Depositar(contaId, valor);
        }

        // SAQUE (diferenças entre corrente e poupança)
        public void Sacar(int contaId, decimal valor)
        {
            if (valor <= 0)
                throw new Exception("O valor do saque deve ser maior que zero.");

            var conta = repo.ObterPorId(contaId);
            if (conta == null)
                throw new Exception("Conta não encontrada.");

            // regra para poupança
            if (conta.TipoConta == "POUPANCA" && conta.Saldo < valor)
                throw new Exception("Poupança não pode ficar negativa.");

            // regra para corrente
            if (conta.TipoConta == "CORRENTE" && conta.Saldo < valor)
                throw new Exception("Saldo insuficiente.");

            repo.Sacar(contaId, valor);
        }

        // TRANSFERÊNCIA
        public void Transferir(int contaOrigem, int contaDestino, decimal valor)
        {
            if (valor <= 0)
                throw new Exception("O valor da transferência deve ser maior que zero.");

            var origem = repo.ObterPorId(contaOrigem);
            var destino = repo.ObterPorId(contaDestino);

            if (origem == null || destino == null)
                throw new Exception("Conta de origem ou destino não encontrada.");

            // regra da poupança → não pode transferir se ficar negativa
            if (origem.TipoConta == "POUPANCA" && origem.Saldo < valor)
                throw new Exception("Poupança não permite transferência sem saldo suficiente.");

            // conta corrente → cheque especial opcional
            if (origem.TipoConta == "CORRENTE" && origem.Saldo < valor)
                throw new Exception("Saldo insuficiente para transferência.");

            // executa
            repo.Transferir(contaOrigem, contaDestino, valor);
        }

        // CRIAR CONTA
        public void CriarConta(string numero, int clienteId, string tipoConta)
        {
            if (string.IsNullOrWhiteSpace(numero))
                throw new Exception("Número da conta inválido.");

            if (string.IsNullOrWhiteSpace(tipoConta))
                throw new Exception("Tipo da conta inválido.");

            var conta = new Conta
            {
                Numero = numero,
                Saldo = 0,
                ClienteId = clienteId,
                TipoConta = tipoConta
            };

            repo.CriarConta(conta);
        }

        // DELETAR CONTA
        public void DeletarConta(int contaId)
        {
            var conta = repo.ObterPorId(contaId);
            if (conta == null)
                throw new Exception("Conta não encontrada.");

            repo.Deletar(contaId);
        }
    }
}
