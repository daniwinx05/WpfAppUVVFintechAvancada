﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Model;
using WpfAppUVVFintechAvancada.Repositories;

namespace WpfAppUVVFintechAvancada.Controller
{
    internal class UsuarioController
    {
        private readonly UsuarioRepository repo = new UsuarioRepository();

        public Usuario Login(string email, string senha)
        {
            return repo.Login(email, senha);
        }
    }
}
