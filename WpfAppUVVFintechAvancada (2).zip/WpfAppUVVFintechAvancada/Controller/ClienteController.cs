﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Model;
using WpfAppUVVFintechAvancada.Repositories;

namespace WpfAppUVVFintechAvancada.Controller
{
    internal class ClienteController
    {
        private readonly ClienteRepository repo = new ClienteRepository();

        public void Cadastrar(string nome, string cpf, DateTime dataNasc, string senha)
        {
            var cliente = new Cliente
            {
                Nome = nome,
                Cpf = cpf,
                DataNascimento = dataNasc,
                Senha = senha
            };

            repo.Inserir(cliente);
        }

        public Cliente Buscar(int id)
        {
            return repo.BuscarPorId(id);
        }

        public void Atualizar(int id, string nome, string cpf, DateTime dataNasc, string senha)
        {
            var cliente = new Cliente
            {
                ClienteId = id,
                Nome = nome,
                Cpf = cpf,
                DataNascimento = dataNasc,
                Senha = senha
            };

            repo.Atualizar(cliente);
        }

        public void Deletar(int id)
        {
            repo.Deletar(id);
        }


    }
}

