﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppUVVFintechAvancada.Model.Enums
{
    public enum TipoUsuario : int
    {
        Cliente = 1,
        Administrador = 2
    }
}
