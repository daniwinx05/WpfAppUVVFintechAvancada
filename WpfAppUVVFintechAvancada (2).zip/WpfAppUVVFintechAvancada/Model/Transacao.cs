﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Model.Enums;


namespace WpfAppUVVFintechAvancada.Model
{
    internal class Transacao
    {
        public int TransacaoId { get; set; }
        public decimal Valor { get; set; }
        public string Tipo { get; set; }     // Débito, Crédito, Saque, Depósito, Transferência
        public DateTime Data { get; set; }
        public string Observacao { get; set; }
        public int ContaId { get; set; }
    }
}
