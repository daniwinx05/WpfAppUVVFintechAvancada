﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppUVVFintechAvancada.Model
{
    internal class Conta
    {
        
            public int ContaId { get; set; }         // PK
            public string Numero { get; set; }       // Número da conta (ex: 0001-1)
            public decimal Saldo { get; set; }       // Saldo atual
            public int ClienteId { get; set; }       // FK para Cliente
            public string TipoConta { get; set; }    // CORRENTE ou POUPANCA
        
    }
}
