﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Model;
using WpfAppUVVFintechAvancada.Controller;

namespace WpfAppUVVFintechAvancada
{

    public partial class DeletarCliente : Window
    {   
        private readonly ClienteController controller = new ClienteController();

        public DeletarCliente()
        {
            InitializeComponent();
        }

        

        private void Deletar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = int.Parse(txtIdCliente.Text);

                var cliente = controller.Buscar(id);
                if (cliente == null)
                {
                    MessageBox.Show("Cliente não encontrado.");
                    return;
                }

                var confirmar = MessageBox.Show(
                    $"Tem certeza que deseja deletar o cliente '{cliente.Nome}'?",
                    "Confirmar",
                    MessageBoxButton.YesNo);

                if (confirmar == MessageBoxResult.Yes)
                {
                    controller.Deletar(id);
                    MessageBox.Show("Cliente deletado com sucesso!");

                    txtIdCliente.Text = "";
                    txtNome.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao deletar: " + ex.Message);
            }
        }
    }
}
