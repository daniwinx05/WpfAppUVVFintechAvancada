﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Controller;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para EditarCliente2.xaml
    /// </summary>
    public partial class EditarCliente2 : Window
    {
        public EditarCliente2()
        {
            InitializeComponent();
        }

        private void Atualizar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var controller = new ClienteController();

                controller.Atualizar(
                    int.Parse(txtId.Text),
                    txtNome.Text,
                    txtCpf.Text,
                    DateTime.Parse(txtDataNasc.Text),
                    txtSenha.Password
                );

                MessageBox.Show("Cliente atualizado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar: " + ex.Message);
            }
        }


        private void Buscar_Click(object sender, RoutedEventArgs e)
        {
            var controller = new ClienteController();
            int id = int.Parse(txtId.Text);

            var cliente = controller.Buscar(id);

            if (cliente == null)
            {
                MessageBox.Show("Cliente não encontrado");
                return;
            }

            txtNome.Text = cliente.Nome;
            txtCpf.Text = cliente.Cpf;
            txtDataNasc.Text = cliente.DataNascimento.ToString("dd/MM/yyyy");
            txtSenha.Password = cliente.Senha;

        }
    }
}
