﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Controller;
using WpfAppUVVFintechAvancada.Model;

namespace WpfAppUVVFintechAvancada
{
    public partial class GerenciarClientes : Window
    {
        private Administrador _adiministrador;
        private ContaController _contaController = new ContaController();
        public GerenciarClientes(Administrador adiministrador)
        {
            InitializeComponent();
            _adiministrador = adiministrador;
        }

        private void BtnCriar_Click(object sender, RoutedEventArgs e)
        {
            var  cria = new CriarCliente();
            cria.Closed += (s, args) => new GerenciarClientes(_adiministrador).Show();

            cria.Show();
            this.Close();
        }

        private void BtnEditar_Click(object sender, RoutedEventArgs e)
        {
            var editar = new EditarCliente2();
            editar.Closed += (s, args) => new GerenciarClientes(_adiministrador).Show();
            editar.Show();
            this.Close();
        }

        private void BtnDeletar_Click(object sender, RoutedEventArgs e)
        {
            var deletar = new DeletarCliente();
            deletar.Closed += (s, args) => new GerenciarClientes(_adiministrador).Show();

            deletar.Show();
            this.Close();
        }
    }
}
