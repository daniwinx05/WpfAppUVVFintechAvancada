﻿using Microsoft.Data.SqlClient;
using System.Windows;
using WpfAppUVVFintechAvancada.Config;
using WpfAppUVVFintechAvancada.Controller;
using WpfAppUVVFintechAvancada.Model;
using static WpfAppUVVFintechAvancada.Model.Administrador;


namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }



        

        private void BtnTestarConexao_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection conn = Conexao.Conectar())
                {
                    conn.Open();
                    MessageBox.Show("Conexão bem sucedida com o banco!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha ao conectar: " + ex.Message);
            }
        }

        private void BtnEntrar_Click(object sender, RoutedEventArgs e)
        {
            string tipo = txtTipo.Text.Trim().ToUpper();
            string nome = txtNome.Text.Trim();
            string senha = txtSenha.Password.Trim();

            var loginController = new LoginController();
            var usuario = loginController.Login(tipo, nome, senha);

            if (usuario is Administrador admin)
            {
                var TelaGConta = new GerenciarClientes(admin);
                TelaGConta.Show();
                this.Close();
            }

            else if (usuario is Cliente cliente)
            {
                var Tela = new GerenciaTransacao(cliente);
                Tela.Show();
                this.Close();
            }



        }

        private void BtnCriar_Click(object sender, RoutedEventArgs e)
        {
            var CriaCliente = new CriarCliente(); // instancia a janela
            //CriaCliente.Closed += (s, args) => new MainWindow().Show();

            CriaCliente.Show(); // abre
            this.Close();
        }
    }
}