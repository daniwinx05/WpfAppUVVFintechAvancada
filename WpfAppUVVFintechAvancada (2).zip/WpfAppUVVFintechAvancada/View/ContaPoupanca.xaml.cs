﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Model;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para ContaPoupanca.xaml
    /// </summary>
    public partial class ContaPoupanca : Window
    {
        private string _nomeCliente;
        private int _contaId;

        public ContaPoupanca(string nomeCliente, int contaId)
        {
            InitializeComponent();
            _nomeCliente = nomeCliente;
            _contaId = contaId;

            lblCliente.Content = nomeCliente;
        }



        private void buttonDeposito_Click(object sender, RoutedEventArgs e)
        {
            var deposito = new Deposito(_contaId);
            deposito.Show();
            this.Close();
        }

         
       

        private void buttonTransferencia_Click(object sender, RoutedEventArgs e)
        {
            var transferencia = new Transferencia(_contaId);
            transferencia.Show();
            this.Close();
        }

        private void buttonSaque_Click_1(object sender, RoutedEventArgs e)
        {
            var saque = new Saque(_contaId);
            saque.Show();
            this.Close();
        }
    }
}
