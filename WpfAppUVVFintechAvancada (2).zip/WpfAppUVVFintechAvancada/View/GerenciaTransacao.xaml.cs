﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Controller;
using WpfAppUVVFintechAvancada.Model;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para GerenciaTransacao.xaml
    /// </summary>
    public partial class GerenciaTransacao : Window
    {
        private Cliente _cliente;
        private ContaController _contaController = new ContaController();

        public GerenciaTransacao(Cliente cliente)
        {
            InitializeComponent();
            _cliente = cliente;

            lblCliente.Content = cliente.Nome;
        }

        private int ObterContaPoupanca()
        {
            var contas = _contaController.ObterContasDoCliente(_cliente.ClienteId);
            return contas.First(c => c.TipoConta == "POUPANCA").ContaId;
        }

        private int ObterContaCorrente()
        {
            var contas = _contaController.ObterContasDoCliente(_cliente.ClienteId);
            return contas.First(c => c.TipoConta == "CORRENTE").ContaId;
        }

        private void ContaP_Click(object sender, RoutedEventArgs e)
        {
           
        
            int contaId = ObterContaPoupanca(); // <- REAL ContaId do banco

            var tela = new ContaPoupanca(_cliente.Nome, contaId);
            tela.Show();
            this.Close();
        

        }

        private void ContaC_Click(object sender, RoutedEventArgs e)
        {

        }

        /*
        private void ContaC_Click(object sender, RoutedEventArgs e)
        {
            int contaId = ObterContaCorrente();
            var tela = new ContaCorrente(_cliente.Nome, contaId);
            tela.Show();
            this.Close();
        }
        */
    }
}
