﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Controller;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para Transferencia.xaml
    /// </summary>
    public partial class Transferencia : Window
    {
        private int _contaId;
        private ContaController _controller = new ContaController();

        public Transferencia(int contaId)
        {
            InitializeComponent();
            _contaId = contaId;
        }

        private void Confirmar_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
