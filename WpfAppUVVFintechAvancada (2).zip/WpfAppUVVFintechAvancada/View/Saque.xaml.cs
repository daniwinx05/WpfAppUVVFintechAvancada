﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Controller;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para Saque.xaml
    /// </summary>
    public partial class Saque : Window
    {
        private readonly int _contaId;
        private readonly ContaController _controller = new ContaController();

        public Saque(int contaId)
        {
            InitializeComponent();
            _contaId = contaId;
            AtualizarSaldo();
        }

        private void AtualizarSaldo()
        {
            decimal saldo = _controller.ObterSaldo(_contaId);
            lblSaldo.Content = $"Saldo: R$ {saldo:F2}";
        }


        private void Confirmar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!decimal.TryParse(txtValorSaque.Text, out decimal valor))
                {
                    MessageBox.Show("Digite um valor válido.");
                    return;
                }

                // Verifica saldo
                decimal saldoAtual = _controller.ObterSaldo(_contaId);

                if (valor <= 0)
                {
                    MessageBox.Show("O valor deve ser maior que zero.");
                    return;
                }

                if (valor > saldoAtual)
                {
                    MessageBox.Show("Saldo insuficiente.");
                    return;
                }

                // Efetua saque
                _controller.Sacar(_contaId, valor);

                MessageBox.Show("Saque realizado com sucesso!");

                AtualizarSaldo();
                lblSaldo.Content = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }
    }
}
