﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Controller;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para CriarCliente.xaml
    /// </summary>
    public partial class CriarCliente : Window
    {
        public CriarCliente()
        {
            InitializeComponent();
        }

        private void Criar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var controller = new ClienteController();

                controller.Cadastrar(
                    txtNome.Text.Trim(),
                    txtCpf.Text.Trim(),
                    DateTime.Parse(txtDataNasc.Text),
                    txtSenha.Password.Trim()
                );

                MessageBox.Show("Cliente cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar: " + ex.Message);
            }
        }

        private void Cancelar_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
