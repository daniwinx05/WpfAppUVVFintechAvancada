﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppUVVFintechAvancada.Controller;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para Deposito.xaml
    /// </summary>
    public partial class Deposito : Window
    {

        private readonly int _contaId;
        private readonly ContaController _controller = new ContaController();


        public Deposito(int contaId)
        {
            InitializeComponent();
            _contaId = contaId;

            MessageBox.Show("ContaId recebido: " + _contaId); // MOSTRAR ID
            AtualizarSaldo();
        }

        private void AtualizarSaldo()
        {
            decimal saldo = _controller.ObterSaldo(_contaId);
            lblSaldo.Content = $"Saldo: R$ {saldo:F2}";
        }

        private void buttonConfirmarDeposito_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                decimal valor = decimal.Parse(txtDeposito.Text);

                _controller.Depositar(_contaId, valor);

                MessageBox.Show("Depósito realizado com sucesso!");

                AtualizarSaldo();
                txtDeposito.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }
    }
}
