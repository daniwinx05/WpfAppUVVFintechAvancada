﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para ContaCorrente.xaml
    /// </summary>
    public partial class ContaCorrente : Window
    {
        private string _nomeCliente;
        private int _contaId;
        public ContaCorrente()
        {
            InitializeComponent();
        }
        public ContaCorrente(string nomeCliente)
        {
            _nomeCliente = nomeCliente;

            // Atualiza o texto na interface
            lblCliente.Content = $"{_nomeCliente}";
            MessageBox.Show($"Conta ID: {_contaId}");
        }

       
        private void buttonSaque_Click(object sender, RoutedEventArgs e)
        {
            var saque = new Saque(_contaId);
            saque.Show();
            this.Close();

        }

        private void buttonDeposito_Click(object sender, RoutedEventArgs e)
        {
            var deposito = new Deposito(_contaId);
            deposito.Show();
            this.Close();
           

        }

        private void buttonTranferencia_Click(object sender, RoutedEventArgs e)
        {

        }
        /*
private void buttonTranferencia_Click(object sender, RoutedEventArgs e)
{
   var transferir = new Transferencia();
   transferir.Show();
   this.Close();
}
*/
    }
}
