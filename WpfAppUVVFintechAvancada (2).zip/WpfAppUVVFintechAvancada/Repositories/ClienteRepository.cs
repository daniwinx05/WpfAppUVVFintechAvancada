﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Config;
using WpfAppUVVFintechAvancada.Model;

namespace WpfAppUVVFintechAvancada.Repositories
{
    internal class ClienteRepository
    {
        public Cliente LoginPorNome(string nome, string senha)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = @"SELECT * FROM Clientes
                               WHERE Nome = @Nome AND Senha = @Senha";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Nome", nome);
                    cmd.Parameters.AddWithValue("@Senha", senha);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Cliente
                            {
                                ClienteId = (int)reader["ClienteId"],
                                Nome = reader["Nome"].ToString(),
                                Cpf = reader["Cpf"].ToString(),
                                DataNascimento = Convert.ToDateTime(reader["DataNascimento"]),
                                Senha = reader["Senha"].ToString()
                            };
                        }
                    }
                }
            }

            return null;
        }

        // CRIAR cliente
        public void Inserir(Cliente cliente)
        {
            using (SqlConnection conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = @"INSERT INTO Clientes (Nome, Cpf, DataNascimento, Senha)
                               VALUES (@Nome, @Cpf, @DataNascimento, @Senha)";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
                    cmd.Parameters.AddWithValue("@Cpf", cliente.Cpf);
                    cmd.Parameters.AddWithValue("@DataNascimento", cliente.DataNascimento);
                    cmd.Parameters.AddWithValue("@Senha", cliente.Senha);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        // BUSCAR cliente por ID
        public Cliente BuscarPorId(int id)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();
                string sql = "SELECT * FROM Clientes WHERE ClienteId = @Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Cliente
                            {
                                ClienteId = (int)reader["ClienteId"],
                                Nome = reader["Nome"].ToString(),
                                Cpf = reader["Cpf"].ToString(),
                                DataNascimento = Convert.ToDateTime(reader["DataNascimento"]),
                                Senha = reader["Senha"].ToString()
                            };
                        }
                    }
                }
            }

            return null;
        }

        // ATUALIZAR cliente
        public void Atualizar(Cliente cliente)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = @"UPDATE Clientes
                               SET Nome = @Nome,
                                   Cpf = @Cpf,
                                   DataNascimento = @DataNascimento,
                                   Senha = @Senha
                               WHERE ClienteId = @ClienteId";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@ClienteId", cliente.ClienteId);
                    cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
                    cmd.Parameters.AddWithValue("@Cpf", cliente.Cpf);
                    cmd.Parameters.AddWithValue("@DataNascimento", cliente.DataNascimento);
                    cmd.Parameters.AddWithValue("@Senha", cliente.Senha);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        // DELETAR cliente
        
        
            public void Deletar(int id)
            {
                using (var conn = Conexao.Conectar())
                {
                    conn.Open();

                    string sql = "DELETE FROM Clientes WHERE ClienteId = @Id";

                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
            }

        }

    }


