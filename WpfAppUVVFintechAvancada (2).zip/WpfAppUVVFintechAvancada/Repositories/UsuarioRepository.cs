﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Config;
using WpfAppUVVFintechAvancada.Model;

namespace WpfAppUVVFintechAvancada.Repositories
{
    internal class UsuarioRepository
    {
        public Usuario Login(string email, string senha)
        {
            using (SqlConnection conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = @"SELECT * FROM Usuarios
                               WHERE Email = @Email AND Senha = @Senha";

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Senha", senha);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Usuario
                            {
                                UsuarioId = (int)reader["UsuarioId"],
                                Email = reader["Email"].ToString(),
                                Senha = reader["Senha"].ToString(),
                                TipoUsuario = reader["TipoUsuario"].ToString()
                            };
                        }
                    }
                }
            }

            return null;
        }
    }
}
