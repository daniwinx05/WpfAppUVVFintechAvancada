﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Config;
using WpfAppUVVFintechAvancada.Model;

namespace WpfAppUVVFintechAvancada.Repositories
{
    internal class ContaRepository
    {
        // BUSCAR UMA CONTA POR ID
        public Conta ObterPorId(int id)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = "SELECT * FROM Contas WHERE ContaId = @Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Conta
                            {
                                ContaId = (int)reader["ContaId"],
                                Numero = reader["Numero"].ToString(),
                                Saldo = Convert.ToDecimal(reader["Saldo"]),
                                ClienteId = (int)reader["ClienteId"],
                                TipoConta = reader["TipoConta"].ToString()
                            };
                        }
                    }
                }
            }

            return null;
        }

        // BUSCAR TODAS AS CONTAS DE UM CLIENTE
        public List<Conta> BuscarPorCliente(int clienteId)
        {
            var lista = new List<Conta>();

            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = "SELECT * FROM Contas WHERE ClienteId = @Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", clienteId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lista.Add(new Conta
                            {
                                ContaId = (int)reader["ContaId"],
                                Numero = reader["Numero"].ToString(),
                                Saldo = Convert.ToDecimal(reader["Saldo"]),
                                ClienteId = (int)reader["ClienteId"],
                                TipoConta = reader["TipoConta"].ToString()
                            });
                        }
                    }
                }
            }

            return lista;
        }

        // OBTER SALDO
        public decimal ObterSaldo(int contaId)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = "SELECT Saldo FROM Contas WHERE ContaId = @Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", contaId);

                    object resultado = cmd.ExecuteScalar();
                    return Convert.ToDecimal(resultado);
                }
            }
        }

        // DEPOSITAR (Stored Procedure)
        public void Depositar(int contaId, decimal valor)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                using (var cmd = new SqlCommand("Depositar", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ContaId", contaId);
                    cmd.Parameters.AddWithValue("@Valor", valor);
                    cmd.Parameters.AddWithValue("@Descricao", "Depósito via App");

                    cmd.ExecuteNonQuery();
                }
            }
        }


        // SACAR (Stored Procedure)
        public void Sacar(int contaId, decimal valor)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                using (var cmd = new SqlCommand("Sacar", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ContaId", contaId);
                    cmd.Parameters.AddWithValue("@Valor", valor);
                    cmd.Parameters.AddWithValue("@Descricao", "Saque via App");

                    cmd.ExecuteNonQuery();
                }
            }
        }


        // TRANSFERIR (lógica dupla)
        public void Transferir(int contaOrigem, int contaDestino, decimal valor)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                using (var trans = conn.BeginTransaction())
                {
                    try
                    {
                        // SAQUE NA ORIGEM
                        using (var cmd = new SqlCommand("Sacar", conn, trans))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@ContaId", contaOrigem);
                            cmd.Parameters.AddWithValue("@Valor", valor);
                            cmd.Parameters.AddWithValue("@Observacao", "Transferência - Saída");
                            cmd.ExecuteNonQuery();
                        }

                        // DEPÓSITO NO DESTINO
                        using (var cmd = new SqlCommand("Depositar", conn, trans))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@ContaId", contaDestino);
                            cmd.Parameters.AddWithValue("@Valor", valor);
                            cmd.Parameters.AddWithValue("@Observacao", "Transferência - Entrada");
                            cmd.ExecuteNonQuery();
                        }

                        trans.Commit();
                    }
                    catch
                    {
                        trans.Rollback();
                        throw;
                    }
                }
            }
        }

        // CRIAR CONTA
        public void CriarConta(Conta conta)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = @"INSERT INTO Contas (Numero, Saldo, ClienteId, TipoConta)
                               VALUES (@Numero, @Saldo, @ClienteId, @TipoConta)";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Numero", conta.Numero);
                    cmd.Parameters.AddWithValue("@Saldo", conta.Saldo);
                    cmd.Parameters.AddWithValue("@ClienteId", conta.ClienteId);
                    cmd.Parameters.AddWithValue("@TipoConta", conta.TipoConta);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        // DELETAR CONTA
        public void Deletar(int contaId)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = "DELETE FROM Contas WHERE ContaId = @Id";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", contaId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

    }
}
