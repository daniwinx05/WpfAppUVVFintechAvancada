﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Config;
using WpfAppUVVFintechAvancada.Model;

namespace WpfAppUVVFintechAvancada.Repositories
{
    internal class TransacaoRepository
    {
        public List<Transacao> BuscarPorConta(int contaId)
        {
            var lista = new List<Transacao>();

            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = @"SELECT TransacaoId, Valor, Tipo, ContaId,
                                      Observacao, Data
                               FROM Transacoes 
                               WHERE ContaId = @ContaId
                               ORDER BY Data DESC";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@ContaId", contaId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            lista.Add(new Transacao
                            {
                                TransacaoId = (int)reader["TransacaoId"],
                                Valor = Convert.ToDecimal(reader["Valor"]),
                                Tipo = reader["Tipo"].ToString(),
                                ContaId = (int)reader["ContaId"],
                                Observacao = reader["Observacao"].ToString(),
                                Data = Convert.ToDateTime(reader["Data"])
                            });
                        }
                    }
                }
            }

            return lista;
        }
    }
}
