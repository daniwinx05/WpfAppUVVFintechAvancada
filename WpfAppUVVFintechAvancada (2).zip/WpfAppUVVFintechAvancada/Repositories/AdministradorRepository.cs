﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Config;
using WpfAppUVVFintechAvancada.Model;
using static WpfAppUVVFintechAvancada.Model.Administrador;


namespace WpfAppUVVFintechAvancada.Repositories
{
    internal class AdministradorRepository
    {
        public Administrador Login(string nome, string senha)
        {
            using (var conn = Conexao.Conectar())
            {
                conn.Open();

                string sql = @"SELECT * FROM Administradores
                               WHERE Nome = @Nome AND Senha = @Senha";

                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Nome", nome);
                    cmd.Parameters.AddWithValue("@Senha", senha);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Administrador
                            {
                                AdminId = (int)reader["AdminId"],
                                Nome = reader["Nome"].ToString(),
                                Senha = reader["Senha"].ToString()
                            };
                        }
                    }
                }
            }

            return null; // se não encontrou
        }
    }
}
