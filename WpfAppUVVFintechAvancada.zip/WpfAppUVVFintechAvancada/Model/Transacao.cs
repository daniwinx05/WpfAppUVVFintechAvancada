﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Model.Enums;


namespace WpfAppUVVFintechAvancada.Model
{
    internal class Transacao
    {
        public int Id { get; set; }

        public TipoTransacao Tipo { get; set; }

        // Conta relacionada (a conta que sofreu a operação)
        public int ContaId { get; set; }
        public Conta Conta { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Valor { get; set; }

        // Em transferências, pode haver ContaDestinoId
        public int? ContaDestinoId { get; set; }

        public DateTime DataHora { get; set; } = DateTime.UtcNow;

        public string Observacao { get; set; }
    }
}
