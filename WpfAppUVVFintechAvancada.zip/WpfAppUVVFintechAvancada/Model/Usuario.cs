﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppUVVFintechAvancada.Model.Enums;

namespace WpfAppUVVFintechAvancada.Model
{
    internal class Usuario
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Nome { get; set; }

        [Required, StringLength(14)]
        public string CPF { get; set; } // ou use string com validação externa

        [Required, StringLength(50)]
        public string Login { get; set; }

        [Required]
        public string SenhaHash { get; set; } // somente hash

        [Required]
        public TipoUsuario Tipo { get; set; } = TipoUsuario.Cliente;

        public bool Ativo { get; set; } = true;

        // Navegação: cliente pode ter 0 ou 1 conta (admins normalmente não)
        public Conta Conta { get; set; }
    }
}
