﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppUVVFintechAvancada.Model.Enums
{
    public enum TipoTransacao : int
    {
        Deposito = 1,
        Saque = 2,
        Transferencia = 3
    }
}
