﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppUVVFintechAvancada.Model
{
    internal class Conta
    {
        public int Id { get; set; }

        // FK para Usuario
        public int UsuarioId { get; set; }
        public Usuario Usuario { get; set; }

        // define precisão; EF Core respeita Column(TypeName=...)
        [Column(TypeName = "decimal(18,2)")]
        public decimal Saldo { get; private set; } = 0m;

        public DateTime DataCriacao { get; set; } = DateTime.UtcNow;

        // Histórico de transações
        public ICollection<Transacao> Transacoes { get; set; } = new List<Transacao>();

        // Métodos de domínio — validam regras aqui
        public void Depositar(decimal valor)
        {
            if (valor <= 0) throw new ArgumentException("Valor deve ser maior que zero.", nameof(valor));
            Saldo += valor;
        }

        public bool Sacar(decimal valor)
        {
            if (valor <= 0) throw new ArgumentException("Valor deve ser maior que zero.", nameof(valor));
            if (valor > Saldo) return false;
            Saldo -= valor;
            return true;
        }
    }
}
