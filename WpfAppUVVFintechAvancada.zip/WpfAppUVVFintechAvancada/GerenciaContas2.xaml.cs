﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppUVVFintechAvancada
{
    public partial class GerenciaContas2 : Window
    {
        private string _nome;
        private string _conta;

        public GerenciaContas2(string nome, string conta)
        {
            InitializeComponent();

            _nome = nome;
            _conta = conta;

            lblCliente.Text = $"{_nome} — nº {_conta}";
        }

        private void BtnSaldo_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Aqui você exibirá o saldo.",
                            "Saldo", MessageBoxButton.OK);
        }

        private void BtnExtrato_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Aqui você exibirá o extrato.",
                            "Extrato", MessageBoxButton.OK);
        }

        private void BtnComprovantes_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Aqui você exibirá os comprovantes.",
                            "Comprovantes", MessageBoxButton.OK);
        }
    }
}