﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppUVVFintechAvancada
{
    public partial class GerenciaContas1 : Window
    {
        public GerenciaContas1()
        {
            InitializeComponent();
        }

        private void BtnEntrar_Click(object sender, RoutedEventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string cpf = txtNumeroConta.Text.Trim();

            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(cpf))
            {
                lblErro.Text = "Preencha todos os campos.";
                return;
            }

            // VALIDAÇÃO FAKE — só pra testar o fluxo
            bool clienteExiste = true;

            if (!clienteExiste)
            {
                lblErro.Text = "Cliente não encontrado.";
                return;
            }

            // Chamar a tela de baixo — depois vamos ajustar
            GerenciaContas2 tela = new GerenciaContas2(nome, "****");
            tela.Show();
            this.Close();
        }
    }
}