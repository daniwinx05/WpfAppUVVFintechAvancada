﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppUVVFintechAvancada
{
    /// <summary>
    /// Lógica interna para ContaPoupanca.xaml
    /// </summary>
    public partial class ContaPoupanca : Window
    {
        public ContaPoupanca()
        {
            InitializeComponent();
        }

        private void buttonTransferencia_Click(object sender, RoutedEventArgs e)
        {

        }

        private void buttonSaque_Click(object sender, RoutedEventArgs e)
        {

        }

        private void buttonDeposito_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
